<?php

/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en « wp-config.php » et remplir les
 * valeurs.
 *
 * Ce fichier contient les réglages de configuration suivants :
 *
 * Réglages MySQL
 * Préfixe de table
 * Clés secrètes
 * Langue utilisée
 * ABSPATH
 *
 * @link https://fr.wordpress.org/support/article/editing-wp-config-php/.
 *
 * @package WordPress
 */

define('WP_POST_REVISIONS', 3);
define('AUTOSAVE_INTERVAL', 360);

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define('DB_NAME', 'evalwp');

/** Utilisateur de la base de données MySQL. */
define('DB_USER', 'root');

/** Mot de passe de la base de données MySQL. */
define('DB_PASSWORD', '');

/** Adresse de l’hébergement MySQL. */
define('DB_HOST', 'localhost');

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define('DB_CHARSET', 'utf8mb4');

/**
 * Type de collation de la base de données.
 * N’y touchez que si vous savez ce que vous faites.
 */
define('DB_COLLATE', '');

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clés secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'VEi;1E(yU(Zz]E#)J=lDO rS K2 uV9)k|?;XnbP(Mx$!mL/-G- *Y#$&WZM#jos');
define('SECURE_AUTH_KEY',  'd:$Q. @+BG)Z%7j@.?,{;G}V1~LVrp}N=4,_%[dEakx:@.$[jUBwMqU6c)Y{[mZW');
define('LOGGED_IN_KEY',    's$y7$/X|67p89fi+F:|rT,m@)HIOj$jY&Jd?+@G90YXeNawzYncG:8H#g%Ok5=<%');
define('NONCE_KEY',        'MF7^)b[R$#22u(F*!B3*5#sO?Py)va4{(Ts=WG_vf%Y5N^yD)&N^W,1wK; _6lxK');
define('AUTH_SALT',        'IHIj53gz`yy7jc|rAc)u)`r?<0rG|]tM+-h80!vUrVP2c,u{-VA%CzOGyWEsGh*$');
define('SECURE_AUTH_SALT', 'UbhY67^##&+1c0wm,3xF4L7Sq|0rKz`[]EZ84Rk5u$:1*hAGl;4iLD/]3/d6%}jF');
define('LOGGED_IN_SALT',   'ms%K;o[!8*:SOd{r+2TZ^: rz MGtDJa!6Q)<BJE&,,c%p|&:u.-wPD4z>P_R#CX');
define('NONCE_SALT',       ';dSImkUADQ?cH)gxe42-D,nR!!RdX:@@/IGGx(A-9BG%| *Vw2$W[y/i)p}@.W{r');
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'iziwp_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortement recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://fr.wordpress.org/support/article/debugging-in-wordpress/
 */
define('WP_DEBUG', false);

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if (!defined('ABSPATH'))
  define('ABSPATH', dirname(__FILE__) . '/');

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once(ABSPATH . 'wp-settings.php');
