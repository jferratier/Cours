<?php
    define("CONTROLLER_DEFAULT", "Articles");
    define("ACTION_DEFAULT", "index");
?>