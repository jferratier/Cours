﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private static readonly HttpClient client = new HttpClient();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void boutonChercher_Click(object sender, RoutedEventArgs e)
        {


            string cs = @"server=localhost;userid=root;password=root;database=kuka";
            using var con = new MySqlConnection(cs);
            con.Open();


            //SELECT One Data
            var stm = "SELECT * FROM `kukas`";
            var cmd = new MySqlCommand(stm, con);
            var v = cmd.ExecuteScalar();
            Console.WriteLine(v);

            //SELECT Many Data
            var stm1 = "SELECT * FROM `kukas`";
            var cmd1 = new MySqlCommand(stm1, con);
            MySqlDataReader read = cmd1.ExecuteReader();

            while (read.Read())
            {
                string test = read.GetString(0) + " " + read.GetString(1);
            }
            read.Close();

            //INSERT
            try
            {
                var stm2 = "INSERT INTO `kukas` (`id`, `name`, `description`, `picture`, `types`, `created`) VALUES (NULL, 'test', 'test', 'test', 'test', '2022-11-17 20:31:07.000000');";
                var cmd2 = new MySqlCommand(stm2, con);
                cmd2.ExecuteNonQuery();
            }
            catch (Exception)
            {
            }


            //UPDATE
            try
            {
                var stm3 = "UPDATE `kukas` SET `name` = 'Machine à café.' WHERE `kukas`.`id` = 1;";
                var cmd3 = new MySqlCommand(stm3, con);
                cmd3.ExecuteNonQuery();
            }
            catch (Exception)
            {
            }


            //DELETE
            try
            {
                var stm4 = "DELETE FROM `kukas` WHERE `kukas`.`id` > 3;";
                var cmd4 = new MySqlCommand(stm4, con);
                cmd4.ExecuteNonQuery();
            }
            catch (Exception)
            {
            }



            string ville = inputVille.Text;
            string response = wsGetVille(ville);
            var detailsVille = JObject.Parse(response);

            var citiesTab = detailsVille.SelectToken("cities");
            if(citiesTab != null)
            {
                var insee = citiesTab[0].SelectToken("insee");
                string resultMeto = wsGetMeteo(insee.ToString());
                var detailsMeteo = JObject.Parse(resultMeto);

                var meteoTab = detailsMeteo.SelectToken("forecast");
                var temps = meteoTab[0].SelectToken("weather");

                // TODO a refaire en plus propre avec https://api.meteo-concept.com/documentation#code-temps
                int valueMeteo = int.Parse(temps.ToString());
                if (valueMeteo > 1 )
                {
                    // Image soleil + nuage
                    Uri fileUri = new Uri(@"T:\Exploitation\CCI\Cours\2022\.Net\WpfApp3\WpfApp3\src\img\2.PNG");
                    imageMeteo.Source = new BitmapImage(fileUri);
                }
                else
                {
                    // Image soleil
                    Uri fileUri = new Uri(@"T:\Exploitation\CCI\Cours\2022\.Net\WpfApp3\WpfApp3\src\img\1.PNG");
                    imageMeteo.Source = new BitmapImage(fileUri);
                }

                labelVille.Content = ville + "  " + insee.ToString();

                
                

               
            }
        }

        private string wsGetVille(string ville)
        {
            var msg = client.GetStringAsync("https://api.meteo-concept.com/api/location/cities?token=f9fbf8ab431e676578b91c6651f7d4c4e9401f41783941523d93115fdff43024&search=" + ville).Result;
            return msg;
        }

        private string wsGetMeteo(string insee)
        {
            var msg = client.GetStringAsync("https://api.meteo-concept.com/api/forecast/daily?token=f9fbf8ab431e676578b91c6651f7d4c4e9401f41783941523d93115fdff43024&insee=" + insee).Result;        
            return msg;
        }

        private void boutonInformations_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
